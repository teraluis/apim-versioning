package helper;

import apim.manager.FileEditor;

public class HelperFile {

	public static void renameProduct(String path, String product, String version) {
		
	}
	
	public static void editFiles() {
		
	}
	
	public static void getDocuments() {
		
	}
	
	public static void renameDocuments() {
		
	}
}
